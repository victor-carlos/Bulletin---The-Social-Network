		<footer class="footer">
			<div class="float-right">Copyright &copy; 2015 - <?php echo date("Y"); ?> | All rights reserved to <a href="#">OverHead</a></div>
			<div class="float-left">
				<p>-- Menu --</p>
				<ul>
					<li><a href="index.php">Home Page</a></li>
					<li><a href="learn/en/privacy.html">Privacy Policy</a></li>
					<li><a href="learn/en/privacy.html#Cookies" >Use of Cookies</a></li>
					<li><a href="learn/en/terms.html">Terms of use</a></li>
					<li><a href="learn/en/index.html">About the Bulletin</a></li>
				</ul>
				
			</div>
			<div style="clear: both;"></div>
		</footer>
	</body>
</html>