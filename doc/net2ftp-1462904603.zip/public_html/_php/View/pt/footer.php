		<footer class="footer">
			<div class="float-right">Copyright &copy; 2015 - <?php echo date("Y"); ?> | Todos os direitos reservados à <a href="#">OverHead</a></div>
			<div class="float-left">
				<p>-- Menu --</p>
				<ul>
					<li><a href="index.php">Página inicial</a></li>
					<li><a href="learn/pt/privacidade.html">Políticas de Privacidade</a></li>
					<li><a href="learn/pt/privacidade.html#Cookies" >Uso de Cookies</a></li>
					<li><a href="learn/pt/termos.html">Termos de Uso</a></li>
					<li><a href="learn/pt/index.html">Sobre o Bulletin</a></li>
				</ul>
				
			</div>
			<div style="clear: both;"></div>
		</footer>
	</body>
</html>